Account
  - Checkin
  - Savings
User
  - Customer
Password protection

Functionality
  - Customer Side
    - list accounts			Mason
    - transaction log		Tim
    - Transfer				Nick
    - Withdrawal			Nick
    - deposit				Nick
    - request account creation		Mason
    
    
Frontend
  - Login screen			Codey
  	- add user				Ian
  - account main page (display each account w/balance)		Nick
  	- deposit					Codey
  	- withdrawal				Tim
  	- transfer					Codey
    - add account				Mason
  - transaction/detail page		Tim
  
  
UML
Account				
  - Checkin			Codey
  - Savings			Tim
Customer			Mason

store data in json files
accounts will be folder systems
  - <Customer identifier>
    - accounts
      -savings
        *each savings account file
      -checkings
        *each checking account file
