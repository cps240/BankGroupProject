package backend.storage;

public abstract class ObjectAlreadyStoredException extends Exception {

	public ObjectAlreadyStoredException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
