/**
 * 
 */
/**
 * This package includes packages that automatically prints objects out to json files as backend.storage. For more information, ask me (Ian Kirkaptrick). I wrote this a couple weeks ago for another project I'm doing and realized it's perfect for storing data in json files.
 * <br>
 * <br>
 * * <strong>look at a tutorial in utils.jsonConversion.Tutorial</strong>
 * <br>
 * @author kirkp1ia
 *
 */
package utils.jsonConversion;